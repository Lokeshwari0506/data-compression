from flask import Flask, render_template
from flask_socketio import SocketIO, emit
import zstandard as zstd
import os
import json
import gzip
import io
import heapq
from collections import Counter
from datetime import datetime
from tabulate import tabulate

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# ======================================================================
# --- CONFIGURATION & INITIAL SETUP ---
# ======================================================================
DICT_FILE = 'multilingual_chat_dict.zstd'
CHAT_LOG_FILE = 'chat_history.json'
ZSTD_ARCHIVE_FILE = 'chat_archive.zst'

# Load dictionary if available
compression_dict = None
if os.path.exists(DICT_FILE):
    try:
        with open(DICT_FILE, 'rb') as f:
            compression_dict = zstd.ZstdCompressionDict(f.read())
        print(f"✓ Loaded compression dictionary from {DICT_FILE}")
        print(f"  Dictionary size: {len(compression_dict.as_bytes()):,} bytes")
    except Exception as e:
        print(f"✗ Failed to load dictionary: {e}")
        compression_dict = None
else:
    print(f"✗ Dictionary file '{DICT_FILE}' not found")
    print("  Run 'python train_dictionary.py' to create one")
    print("  Continuing without dictionary compression...")

# Create Zstd compressor/decompressor
cctx = zstd.ZstdCompressor(
    level=6,
    dict_data=compression_dict,
    write_content_size=False,
    write_checksum=False,
    write_dict_id=False
)
dctx = zstd.ZstdDecompressor(dict_data=compression_dict)

# ======================================================================
# --- LOAD OR INITIALIZE CHAT HISTORY ---
# ======================================================================
if os.path.exists(CHAT_LOG_FILE):
    with open(CHAT_LOG_FILE, 'r', encoding='utf-8') as f:
        chat_log = json.load(f)
    print(f"✓ Loaded previous chat history ({len(chat_log)} messages).")
else:
    chat_log = []

# Persistent compressed stream (append mode)
chat_archive_buffer = open(ZSTD_ARCHIVE_FILE, "ab")
stream_writer = cctx.stream_writer(chat_archive_buffer)

# ======================================================================
# --- BASIC HELPER FUNCTIONS ---
# ======================================================================
def compress_raw(msg_bytes):
    """Compress message bytes with Zstd."""
    min_size = 15 if compression_dict else 50
    if len(msg_bytes) < min_size:
        return False, msg_bytes
    compressed = cctx.compress(msg_bytes)
    if len(compressed) >= len(msg_bytes):
        return False, msg_bytes
    return True, compressed


def decompress_raw(raw_bytes):
    """Decompress Zstd data."""
    return dctx.decompress(raw_bytes)

# ======================================================================
# --- HUFFMAN CODING HELPERS ---
# ======================================================================
class HuffmanNode:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None
    def __lt__(self, other):
        return self.freq < other.freq


def build_huffman_tree(text):
    freq = Counter(text)
    heap = [HuffmanNode(ch, freq[ch]) for ch in freq]
    heapq.heapify(heap)
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged = HuffmanNode(None, left.freq + right.freq)
        merged.left, merged.right = left, right
        heapq.heappush(heap, merged)
    return heap[0] if heap else None


def generate_codes(node, prefix="", codebook=None):
    if codebook is None:
        codebook = {}
    if node is not None:
        if node.char is not None:
            codebook[node.char] = prefix
        generate_codes(node.left, prefix + "0", codebook)
        generate_codes(node.right, prefix + "1", codebook)
    return codebook


def huffman_compress(text):
    if not text:
        return b""
    tree = build_huffman_tree(text)
    codes = generate_codes(tree)
    encoded = "".join(codes[ch] for ch in text)
    b = bytearray()
    for i in range(0, len(encoded), 8):
        byte = encoded[i:i+8]
        b.append(int(byte.ljust(8, '0'), 2))
    return bytes(b)

# ======================================================================
# --- MAIN ROUTES ---
# ======================================================================
@app.route('/')
def home():
    return render_template('index_new.html')

# ======================================================================
# --- SOCKET HANDLERS ---
# ======================================================================
@socketio.on('new_message')
def handle_message(data):
    """Handles incoming messages, stores logs, and compresses."""
    if not isinstance(data, dict) or 'content' not in data:
        print("Received malformed message data.")
        return

    msg_content = data['content']
    sender_id = data['sender_id']
    timestamp = data.get('timestamp', datetime.now().strftime('%H:%M:%S'))

    # Append to in-memory log
    chat_log.append({
        "sender_id": sender_id,
        "timestamp": timestamp,
        "content": msg_content
    })

    # Save to disk
    with open(CHAT_LOG_FILE, 'w', encoding='utf-8') as f:
        json.dump(chat_log, f, ensure_ascii=False, indent=2)

    # Write to Zstd streaming archive
    stream_writer.write(f"[{timestamp}] {sender_id}: {msg_content}\n".encode('utf-8'))

    # Individual message compression stats
    msg_bytes = msg_content.encode('utf-8')
    orig_size = len(msg_bytes)

    # Zstd
    is_compressed, zstd_output = compress_raw(msg_bytes)
    zstd_size = len(zstd_output)
    zstd_ratio = orig_size / zstd_size if zstd_size else 1
    zstd_savings = ((orig_size - zstd_size) / orig_size) * 100 if orig_size else 0

    # Gzip
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', compresslevel=5) as f:
        f.write(msg_bytes)
    gzip_output = buf.getvalue()
    gzip_size = len(gzip_output)
    gzip_ratio = orig_size / gzip_size
    gzip_savings = ((orig_size - gzip_size) / orig_size) * 100

    # Huffman
    huff_output = huffman_compress(msg_content)
    huff_size = len(huff_output)
    huff_ratio = orig_size / huff_size if huff_size else 1
    huff_savings = ((orig_size - huff_size) / orig_size) * 100 if orig_size else 0

    headers = ["Algorithm", "Orig Size (B)", "Compressed (B)", "Ratio", "Savings (%)"]
    rows = [
        ["Zstd" + (" +Dict" if compression_dict else ""), orig_size, zstd_size, f"{zstd_ratio:.2f}x", f"{zstd_savings:.1f}%"],
        ["Gzip", orig_size, gzip_size, f"{gzip_ratio:.2f}x", f"{gzip_savings:.1f}%"],
        ["Huffman", orig_size, huff_size, f"{huff_ratio:.2f}x", f"{huff_savings:.1f}%"],
    ]
    print("\nCompression Comparison Table:")
    print(tabulate(rows, headers=headers, tablefmt="fancy_grid"))

    print(f"Message: {msg_content}")
    print("-" * 60)

    emit('message', {
        'content': msg_content,
        'sender_id': sender_id,
        'timestamp': timestamp
    }, broadcast=True)

# ======================================================================
# --- DISCONNECT HANDLING ---
# ======================================================================
def finalize_compression():
    """Safely finalize compression and print summary."""
    try:
        stream_writer.flush(zstd.FLUSH_FRAME)
        chat_archive_buffer.close()
    except Exception as e:
        print(f"Stream close error: {e}")

    if not chat_log:
        print("No chat messages to summarize.")
        return

    full_chat_text = "\n".join(
        [f"[{m['timestamp']}] {m['sender_id']}: {m['content']}" for m in chat_log]
    ).encode('utf-8')
    orig_size = len(full_chat_text)

    # Zstd
    zstd_compressed = cctx.compress(full_chat_text)
    zstd_size = len(zstd_compressed)
    zstd_ratio = orig_size / zstd_size
    zstd_savings = (1 - zstd_size / orig_size) * 100

    # Gzip
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', compresslevel=6) as f:
        f.write(full_chat_text)
    gzip_data = buf.getvalue()
    gzip_size = len(gzip_data)
    gzip_ratio = orig_size / gzip_size
    gzip_savings = (1 - gzip_size / orig_size) * 100

    # Huffman
    huff_data = huffman_compress(full_chat_text.decode('utf-8'))
    huff_size = len(huff_data)
    huff_ratio = orig_size / huff_size if huff_size else 1
    huff_savings = (1 - huff_size / orig_size) * 100 if orig_size else 0

    headers = ["Algorithm", "Orig (B)", "Compressed (B)", "Ratio", "Savings (%)"]
    rows = [
        [f"Zstd{' +Dict' if compression_dict else ''}", orig_size, zstd_size, f"{zstd_ratio:.2f}x", f"{zstd_savings:.1f}%"],
        ["Gzip", orig_size, gzip_size, f"{gzip_ratio:.2f}x", f"{gzip_savings:.1f}%"],
        ["Huffman", orig_size, huff_size, f"{huff_ratio:.2f}x", f"{huff_savings:.1f}%"],
    ]

    print("\nFinal Compression Summary:")
    print(tabulate(rows, headers=headers, tablefmt="fancy_grid"))
    print(f"\nChat saved with ({len(chat_log)} messages).")
    print(f"🗜️ Compressed archive stored in: {ZSTD_ARCHIVE_FILE}")
    print("-" * 80)

@socketio.on('manual_disconnect')
def handle_manual_disconnect():
    """Triggered manually from client before tab closes."""
    print("\nDisconnect signal received.")
    finalize_compression()

@socketio.on('disconnect')
def handle_disconnect():
    """Triggered automatically if socket closes unexpectedly."""
    print("\nAuto disconnect detected — finalizing compression...\n")
    finalize_compression()

@socketio.on('connect')
def handle_connect():
    dict_bytes = compression_dict.as_bytes() if compression_dict else b''
    status = {
        'compression': 'enabled',
        'dictionary': compression_dict is not None,
        'dict_size': len(dict_bytes)
    }
    print(f"Client connected - Compression: {status['compression']}, Dictionary: {status['dictionary']}")
    emit('compression_status', status)

# ======================================================================
# --- RUN SERVER ---
# ======================================================================
if __name__ == '__main__':
    print("=" * 70)
    print(" Starting Chat Server with Persistent Compression")
    print("=" * 70)
    print(f"Dictionary: {'✓ Loaded' if compression_dict else '✗ Not loaded'}")
    print(f"Compression level: 6")
    print(f"Server: http://0.0.0.0:5001")
    print("=" * 70)
    socketio.run(app, host='0.0.0.0', port=5001, debug=False)
