"""
Train a Zstd dictionary for multilingual chat with emoji support
Focus: English, Tamil-English (Tanglish), Hindi-English (Hinglish) + Emojis
"""
import zstandard as zstd

# Multilingual chat training data with emojis
MULTILINGUAL_CHAT_MESSAGES = [
    # ==================== ENGLISH ====================
    b"hi how are you",
    b"hello there",
    b"good morning",
    b"good night",
    b"how are you doing",
    b"I'm fine thanks",
    b"what are you doing",
    b"nothing much",
    b"just chilling",
    b"what's up",
    b"not much, you",
    b"same here",
    b"okay cool",
    b"that's great",
    b"awesome",
    b"nice one",
    b"sounds good",
    b"alright then",
    b"see you later",
    b"talk to you soon",
    b"catch you later",
    b"goodbye",
    b"bye bye",
    b"take care",
    b"have a great day",
    b"enjoy your weekend",
    b"thank you so much",
    b"thanks a lot",
    b"you're welcome",
    b"no problem",
    b"no worries",
    b"sorry about that",
    b"my bad",
    b"it's okay",
    b"don't worry",
    b"all good",
    b"yeah sure",
    b"of course",
    b"definitely",
    b"maybe later",
    b"I don't know",
    b"I think so",
    b"not sure",
    b"let me check",
    b"give me a minute",
    b"wait a second",
    b"hold on",
    b"be right back",
    b"I'm back",
    b"are you there",
    b"hello anyone",
    b"can you hear me",
    b"yes I can",
    b"loud and clear",
    b"makes sense",
    b"got it",
    b"understood",
    b"I see",
    b"oh really",
    b"wow that's crazy",
    b"no way",
    b"seriously",
    b"just kidding",
    b"haha funny",
    b"that's hilarious",
    b"stop it",
    b"come on",
    b"please help me",
    b"can you help",
    b"I need help",
    b"what happened",
    b"tell me more",
    b"go on",
    b"and then what",
    b"really? tell me",
    b"I'm listening",
    
    # ==================== TAMIL-ENGLISH (TANGLISH) ====================
    b"vanakkam da",
    b"enna da panra",
    b"nalla irukken da",
    b"epdi irukka",
    b"super da",
    b"semma fun",
    b"adipoli",
    b"mass da",
    b"gethu",
    b"vera level",
    b"sema scene",
    b"enna panringa",
    b"sapteengala",
    b"sapdala bro",
b"veetla yaarum illai",
    b"office ku poren",
    b"varen da wait pannu",
    b"late aagum da",
    b"sorry da",
    b"paravala bro",
    b"seri da",
    b"okay da seri",
    b"nalla vishayam",
    b"romba thanks",
    b"thanks da",
    b"welcome da",
    b"mention not",
    b"okay good night",
    b"goodnight da ponga",
    b"kalai vanakkam",
    b"good morning bro",
    b"eppo varuvinga",
    b"seekiram va",
    b"wait pannu coming",
    b"phone pannu",
    b"call panren",
    b"message pannu",
    b"WhatsApp la sollu",
    b"kandipa varuven",
    b"maybe varalaam",
    b"theriyala bro",
    b"puriyala da",
    b"enna solra",
    b"enna achu",
    b"onnum illa",
    b"seri vitudu",
    b"poi tholai",
    b"summa iru",
    b"loosu payale",
    b"dei waste fellow",
    b"comedy pannadha",
    b"vera mari comedy",
    b"ada paavi",
    b"dei dei",
    b"machan",
    b"machi",
    b"bro",
    b"da",
    b"thala",
    b"thambi",
    b"anna",
    b"akka",
    b"sis",
    
    # ==================== HINDI-ENGLISH (HINGLISH) ====================
    b"kya haal hai",
    b"sab theek hai",
    b"main theek hoon",
    b"aur batao",
    b"kya kar rahe ho",
    b"kuch nahi yaar",
    b"bas chill kar raha hoon",
    b"time pass ho raha hai",
    b"bore ho raha hai",
    b"tension mat lo",
    b"chinta mat karo",
    b"sab theek ho jayega",
    b"koi baat nahi",
    b"koi tension nahi",
    b"haan bhai",
    b"nahi yaar",
    b"accha theek hai",
    b"okay bhai",
    b"haan theek",
    b"bilkul sahi",
    b"ekdam correct",
    b"full on masti",
    b"mast hai yaar",
    b"bahut badhiya",
    b"zabardast",
    b"kamaal hai",
    b"kya baat hai",
    b"arre waah",
    b"matlab kya hai",
    b"samajh nahi aaya",
    b"kya matlab",
    b"fir se bolo",
    b"ek baar aur",
    b"kya hua",
    b"kuch nahi",
    b"sab changa",
    b"bas ho gaya",
    b"done ho gaya",
    b"finish kar diya",
    b"main kar loonga",
    b"tu kar le",
    b"abhi karta hoon",
    b"baad mein karoonga",
    b"kal karenge",
    b"aaj nahi yaar",
    b"abhi busy hoon",
    b"free nahi hoon",
    b"time nahi hai",
    b"thoda wait karo",
    b"ruko zara",
    b"ek minute",
    b"bas aa raha hoon",
    b"pohoch gaya",
    b"aa gaya",
    b"chalo bye",
    b"fir milte hai",
    b"baad mein baat karte hai",
    b"phir baat karenge",
    b"WhatsApp kar dena",
    b"call kar diyo",
    b"message kar dena",
    b"haan bhej diya",
    b"dekh liya maine",
    b"pata hai mujhe",
    b"nahi pata yaar",
    b"kaise pata chalega",
    b"google kar le",
    b"search kar lo",
    b"dhyan se dekh",
    b"suno yaar",
    b"arre bhai",
    b"yaar please",
    b"thodi help karo",
    b"thanks bhai",
    b"thank you yaar",
    b"shukriya",
    b"koi na",
    b"welcome hai",
    b"arre sorry yaar",
    b"galti ho gayi",
    b"my bad bhai",
    b"maja aa gaya",
    b"full enjoy kiya",
    b"party thi kya",
    b"hangout karna hai",
    b"chalo somewhere chalte hai",
    b"plan bana lete hai",
    b"bore mat ho",
    
    # ==================== COMMON EMOJIS (UTF-8 Encoded) ====================
    # Smileys & Emotion
    b"\xf0\x9f\x98\x80",  # 😀 grinning face
    b"\xf0\x9f\x98\x81",  # 😁 beaming face
    b"\xf0\x9f\x98\x82",  # 😂 face with tears of joy
    b"\xf0\x9f\xa4\xa3",  # 🤣 rolling on floor laughing
    b"\xf0\x9f\x98\x83",  # 😃 grinning face with big eyes
    b"\xf0\x9f\x98\x84",  # 😄 grinning face with smiling eyes
    b"\xf0\x9f\x98\x85",  # 😅 grinning face with sweat
    b"\xf0\x9f\x98\x86",  # 😆 grinning squinting face
    b"\xf0\x9f\x98\x89",  # 😉 winking face
    b"\xf0\x9f\x98\x8a",  # 😊 smiling face with smiling eyes
    b"\xf0\x9f\x98\x8b",  # 😋 face savoring food
    b"\xf0\x9f\x98\x8e",  # 😎 smiling face with sunglasses
    b"\xf0\x9f\x98\x8d",  # 😍 smiling face with heart-eyes
    b"\xf0\x9f\xa5\xb0",  # 🥰 smiling face with hearts
    b"\xf0\x9f\x98\x98",  # 😘 face blowing a kiss
    b"\xf0\x9f\x98\x97",  # 😗 kissing face
    b"\xf0\x9f\x98\x99",  # 😙 kissing face with smiling eyes
    b"\xf0\x9f\x98\x9a",  # 😚 kissing face with closed eyes
    b"\xf0\x9f\x99\x82",  # 🙂 slightly smiling face
    b"\xf0\x9f\xa4\x97",  # 🤗 hugging face
    b"\xf0\x9f\xa4\xa9",  # 🤩 star-struck
    b"\xf0\x9f\xa4\x94",  # 🤔 thinking face
    b"\xf0\x9f\xa4\xa8",  # 🤨 face with raised eyebrow
    b"\xf0\x9f\x98\x90",  # 😐 neutral face
    b"\xf0\x9f\x98\x91",  # 😑 expressionless face
    b"\xf0\x9f\x98\xb6",  # 😶 face without mouth
    b"\xf0\x9f\x99\x84",  # 🙄 face with rolling eyes
    b"\xf0\x9f\x98\x8f",  # 😏 smirking face
    b"\xf0\x9f\x98\xa3",  # 😣 persevering face
    b"\xf0\x9f\x98\xa5",  # 😥 sad but relieved face
    b"\xf0\x9f\x98\xae",  # 😮 face with open mouth
    b"\xf0\x9f\xa4\x90",  # 🤐 zipper-mouth face
    b"\xf0\x9f\x98\xaf",  # 😯 hushed face
    b"\xf0\x9f\x98\xaa",  # 😪 sleepy face
    b"\xf0\x9f\x98\xab",  # 😫 tired face
    b"\xf0\x9f\xa5\xb1",  # 🥱 yawning face
    b"\xf0\x9f\x98\xb4",  # 😴 sleeping face
    b"\xf0\x9f\x98\x8c",  # 😌 relieved face
    b"\xf0\x9f\x98\x9b",  # 😛 face with tongue
    b"\xf0\x9f\x98\x9c",  # 😜 winking face with tongue
    b"\xf0\x9f\xa4\xaa",  # 🤪 zany face
    b"\xf0\x9f\x98\x9d",  # 😝 squinting face with tongue
    b"\xf0\x9f\xa4\x91",  # 🤑 money-mouth face
    b"\xf0\x9f\xa4\x93",  # 🤓 nerd face
    b"\xf0\x9f\x98\xa2",  # 😢 crying face
    b"\xf0\x9f\x98\xad",  # 😭 loudly crying face
    b"\xf0\x9f\x98\xa4",  # 😤 face with steam from nose
    b"\xf0\x9f\x98\xa0",  # 😠 angry face
    b"\xf0\x9f\x98\xa1",  # 😡 pouting face
    b"\xf0\x9f\xa4\xac",  # 🤬 face with symbols on mouth
    b"\xf0\x9f\xa4\xaf",  # 🤯 exploding head
    b"\xf0\x9f\x98\xb3",  # 😳 flushed face
    b"\xf0\x9f\xa5\xb5",  # 🥵 hot face
    b"\xf0\x9f\xa5\xb6",  # 🥶 cold face
    b"\xf0\x9f\x98\xb1",  # 😱 face screaming in fear
    b"\xf0\x9f\x98\xa8",  # 😨 fearful face
    b"\xf0\x9f\x98\xb0",  # 😰 anxious face with sweat
    b"\xf0\x9f\x98\xa5",  # 😥 sad but relieved face
    b"\xf0\x9f\xa4\x97",  # 🤗 hugging face
    
    # Hand gestures
    b"\xf0\x9f\x91\x8d",  # 👍 thumbs up
    b"\xf0\x9f\x91\x8e",  # 👎 thumbs down
    b"\xf0\x9f\x91\x8c",  # 👌 OK hand
    b"\xe2\x9c\x8c",      # ✌ victory hand
    b"\xf0\x9f\xa4\x9e",  # 🤞 crossed fingers
    b"\xf0\x9f\xa4\x9f",  # 🤟 love-you gesture
    b"\xf0\x9f\xa4\x98",  # 🤘 sign of the horns
    b"\xf0\x9f\x91\x8a",  # 👊 oncoming fist
    b"\xe2\x9c\x8a",      # ✊ raised fist
    b"\xf0\x9f\x91\x8f",  # 👏 clapping hands
    b"\xf0\x9f\x99\x8c",  # 🙌 raising hands
    b"\xf0\x9f\x91\x90",  # 👐 open hands
    b"\xf0\x9f\xa4\xb2",  # 🤲 palms up together
    b"\xf0\x9f\x99\x8f",  # 🙏 folded hands
    b"\xf0\x9f\xa4\x9d",  # 🤝 handshake
    b"\xf0\x9f\x91\x8b",  # 👋 waving hand
    
    # Hearts
    b"\xe2\x9d\xa4",      # ❤ red heart
    b"\xf0\x9f\xa7\xa1",  # 🧡 orange heart
    b"\xf0\x9f\x92\x9b",  # 💛 yellow heart
    b"\xf0\x9f\x92\x9a",  # 💚 green heart
    b"\xf0\x9f\x92\x99",  # 💙 blue heart
    b"\xf0\x9f\x92\x9c",  # 💜 purple heart
    b"\xf0\x9f\x96\xa4",  # 🖤 black heart
    b"\xf0\x9f\xa4\x8d",  # 🤍 white heart
    b"\xf0\x9f\xa4\x8e",  # 🤎 brown heart
    b"\xf0\x9f\x92\x94",  # 💔 broken heart
    b"\xf0\x9f\x92\x95",  # 💕 two hearts
    b"\xf0\x9f\x92\x96",  # 💖 sparkling heart
    b"\xf0\x9f\x92\x97",  # 💗 growing heart
    b"\xf0\x9f\x92\x98",  # 💘 heart with arrow
    b"\xf0\x9f\x92\x9d",  # 💝 heart with ribbon
    b"\xf0\x9f\x92\x9e",  # 💞 revolving hearts
    b"\xf0\x9f\x92\x9f",  # 💟 heart decoration
    
    # Other common
    b"\xf0\x9f\x94\xa5",  # 🔥 fire
    b"\xe2\xad\x90",      # ⭐ star
    b"\xe2\x9c\xa8",      # ✨ sparkles
    b"\xf0\x9f\x92\xaf",  # 💯 hundred points
    b"\xf0\x9f\x92\xaa",  # 💪 flexed biceps
    b"\xf0\x9f\x8e\x89",  # 🎉 party popper
    b"\xf0\x9f\x8e\x82",  # 🎂 birthday cake
    b"\xf0\x9f\x8e\x88",  # 🎈 balloon
    b"\xf0\x9f\x8e\x81",  # 🎁 wrapped gift
    b"\xf0\x9f\x8e\x8a",  # 🎊 confetti ball
    b"\xf0\x9f\x98\x82\xf0\x9f\x98\x82\xf0\x9f\x98\x82",  # 😂😂😂 (multiple emojis)
    b"\xf0\x9f\x91\x8d\xf0\x9f\x91\x8d",  # 👍👍
    b"\xf0\x9f\x94\xa5\xf0\x9f\x94\xa5\xf0\x9f\x94\xa5",  # 🔥🔥🔥
    b"\xe2\x9d\xa4\xef\xb8\x8f\xe2\x9d\xa4\xef\xb8\x8f",  # ❤️❤️
    
    # ==================== MIXED LANGUAGE PHRASES ====================
    b"ok cool da",
    b"thanks yaar",
    b"sorry bro theek hai",
    b"wait pannu bhai",
    b"coming da one minute",
    b"late aagum sorry yaar",
    b"kya semma scene",
    b"bahut mass da",
    b"super bhai vera level",
    b"accha scene da",
    b"seri okay done",
    b"haan thats fine da",
    b"nahi theek illa",
    b"puriyala yaar what you saying",
    b"enna matlab kya hai",
    b"theriyala bhai not sure",
    b"maybe varalaam nahi pata",
    b"call pannu yaar",
    b"WhatsApp message bhej",
    b"photo share karo da",
    b"link send pannunga",
    b"okay goodnight bhai take care",
    b"bye da see you",
]

def train_chat_dictionary(output_file='multilingual_chat_dict.zstd', dict_size=16384):
    """
    Train a dictionary for multilingual chat messages
    
    Args:
        output_file: Where to save the dictionary
        dict_size: Size of dictionary in bytes (16KB for multilingual support)
    """
    print(f"Training multilingual dictionary with {len(MULTILINGUAL_CHAT_MESSAGES)} sample messages...")
    print(f"Languages: English, Tamil-English (Tanglish), Hindi-English (Hinglish)")
    print(f"Emoji support: ✓ Enabled\n")
    
    # Train the dictionary
    dict_data = zstd.train_dictionary(dict_size, MULTILINGUAL_CHAT_MESSAGES)
    
    # Save to file
    with open(output_file, 'wb') as f:
        f.write(dict_data.as_bytes())
    
    print(f"✓ Dictionary saved to {output_file}")
    print(f"  Dictionary size: {len(dict_data.as_bytes()):,} bytes")
    
    # Test the dictionary
    test_compression(dict_data)
    
    return dict_data

def test_compression(dict_data):
    """Test the dictionary on sample multilingual messages"""
    print("\n" + "="*70)
    print("TESTING DICTIONARY COMPRESSION")
    print("="*70)
    
    test_messages = [
        b"hi how are you doing today?",
        b"vanakkam da epdi irukka bro",
        b"kya haal hai yaar sab theek",
        b"ok thats fine da no problem",
        b"sorry yaar galti ho gayi da",
        b"thanks bro romba thanks \xf0\x9f\x98\x82\xf0\x9f\x98\x82",  # with emoji
        b"see you later bye da take care \xf0\x9f\x91\x8d",  # with emoji
        b"enna panra nothing much just chilling",
        b"wait pannu bhai coming one minute",
        b"semma fun yaar party thi kya \xf0\x9f\x94\xa5\xf0\x9f\x94\xa5",  # with emojis
    ]
    
    # Without dictionary
    cctx_no_dict = zstd.ZstdCompressor(level=3)
    
    # With dictionary
    cctx_with_dict = zstd.ZstdCompressor(level=3, dict_data=dict_data)
    
    total_orig = 0
    total_no_dict = 0
    total_with_dict = 0
    
    for i, msg in enumerate(test_messages, 1):
        # Compress without dict
        compressed_no_dict = cctx_no_dict.compress(msg)
        
        # Compress with dict
        compressed_with_dict = cctx_with_dict.compress(msg)
        
        orig_size = len(msg)
        no_dict_size = len(compressed_no_dict)
        with_dict_size = len(compressed_with_dict)
        
        total_orig += orig_size
        total_no_dict += no_dict_size
        total_with_dict += with_dict_size
        
        improvement = ((no_dict_size - with_dict_size) / no_dict_size * 100) if no_dict_size > 0 else 0
        
        # Decode message safely
        try:
            msg_str = msg.decode('utf-8')
        except:
            msg_str = str(msg)
        
        print(f"\n{i}. Message: {msg_str[:50]}{'...' if len(msg_str) > 50 else ''}")
        print(f"   Original:      {orig_size:4d} bytes")
        print(f"   Without dict:  {no_dict_size:4d} bytes (ratio: {orig_size/no_dict_size if no_dict_size > 0 else 0:.2f}x)")
        print(f"   With dict:     {with_dict_size:4d} bytes (ratio: {orig_size/with_dict_size if with_dict_size > 0 else 0:.2f}x)")
        print(f"   Dict benefit:  {improvement:+.1f}%")
    
    print("\n" + "="*70)
    print("OVERALL RESULTS")
    print("="*70)
    print(f"Total original size:           {total_orig:5d} bytes")
    print(f"Total compressed (no dict):    {total_no_dict:5d} bytes ({total_orig/total_no_dict:.2f}x)")
    print(f"Total compressed (with dict):  {total_with_dict:5d} bytes ({total_orig/total_with_dict:.2f}x)")
    print(f"Dictionary improvement:        {((total_no_dict-total_with_dict)/total_no_dict*100):+.1f}%")
    print(f"Space saved by dictionary:     {total_no_dict - total_with_dict} bytes")
    print("="*70)

def load_messages_from_log(log_file):
    """
    Load messages from a log file to train dictionary
    
    Args:
        log_file: Path to file with one message per line
    """
    print(f"Loading messages from {log_file}...")
    with open(log_file, 'r', encoding='utf-8') as f:
        messages = [line.strip().encode('utf-8') for line in f if line.strip()]
    
    print(f"Loaded {len(messages)} messages")
    return messages

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        # Train from log file
        log_file = sys.argv[1]
        output_file = sys.argv[2] if len(sys.argv) > 2 else 'multilingual_chat_dict.zstd'
        
        messages = load_messages_from_log(log_file)
        
        if len(messages) < 10:
            print("Error: Need at least 10 messages to train dictionary")
            sys.exit(1)
        
        MULTILINGUAL_CHAT_MESSAGES = messages
        train_chat_dictionary(output_file)
    else:
        # Train with default multilingual messages
        print("Usage: python train_dict.py [message_log.txt] [output_dict.zstd]")
        print("Training with default multilingual chat messages...\n")
        train_chat_dictionary()